import pygame
import threading
import time
import random
import  math
pygame.init()
win = pygame.display.set_mode((1000, 625))
pygame.display.set_caption('My game')
x = 1000/2 - 51/2
y = 625/2 - 51/2
while True:
    pygame.time.delay(100)
    pygame.display.update()
    win.fill((0,0,0))
    surface = pygame.display.get_surface()
    x, y = surface.get_width(), surface.get_height()
    print(x, y)